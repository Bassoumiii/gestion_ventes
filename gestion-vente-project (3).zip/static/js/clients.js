// Gestion des clients
let clients = []

document.addEventListener("DOMContentLoaded", () => {
  loadClients()
  setupEventListeners()
})

function setupEventListeners() {
  // Recherche avec debounce
  const searchInput = document.getElementById("search-input")
  if (searchInput) {
    searchInput.addEventListener(
      "input",
      debounce(() => {
        filterClients()
      }, 300),
    )
  }

  // Formulaire de client
  const clientForm = document.getElementById("client-form")
  if (clientForm) {
    clientForm.addEventListener("submit", handleClientSubmit)
  }
}

async function loadClients() {
  try {
    clients = await API.get("/api/clients")
    displayClients(clients)
  } catch (error) {
    handleError(error, "lors du chargement des clients")
    displayEmptyState("clients-table", "Erreur de chargement des clients")
  }
}

function displayClients(clientsToShow) {
  const tbody = document.querySelector("#clients-table tbody")
  if (!tbody) return

  tbody.innerHTML = ""

  if (clientsToShow.length === 0) {
    displayEmptyState("clients-table", "Aucun client trouvé")
    return
  }

  clientsToShow.forEach((client) => {
    const row = createTableRow(
      client,
      [
        "id",
        "nom",
        (data) => data.prenom || "-",
        (data) => data.email || "-",
        (data) => formatPhoneNumber(data.telephone) || "-",
        (data) => data.adresse || "-",
      ],
      [
        {
          text: "Modifier",
          icon: "fas fa-edit",
          class: "btn-warning",
          handler: editClient,
        },
        {
          text: "Supprimer",
          icon: "fas fa-trash",
          class: "btn-danger confirm-action",
          handler: deleteClient,
        },
      ],
    )
    tbody.appendChild(row)
  })
}

function displayEmptyState(tableId, message) {
  const tbody = document.querySelector(`#${tableId} tbody`)
  if (!tbody) return

  const colCount = document.querySelectorAll(`#${tableId} thead th`).length
  tbody.innerHTML = `
    <tr>
      <td colspan="${colCount}" class="empty-state">
        <i class="fas fa-users"></i>
        ${message}
      </td>
    </tr>
  `
}

function filterClients() {
  const searchValue = document.getElementById("search-input")?.value || ""

  let filteredClients = clients

  if (searchValue) {
    filteredClients = filteredClients.filter(
      (client) =>
        client.nom.toLowerCase().includes(searchValue.toLowerCase()) ||
        (client.prenom && client.prenom.toLowerCase().includes(searchValue.toLowerCase())) ||
        (client.email && client.email.toLowerCase().includes(searchValue.toLowerCase())) ||
        (client.telephone && client.telephone.includes(searchValue)) ||
        (client.adresse && client.adresse.toLowerCase().includes(searchValue.toLowerCase())),
    )
  }

  displayClients(filteredClients)
}

function openAddModal() {
  document.getElementById("modal-title").innerHTML = '<i class="fas fa-user-plus"></i> Ajouter un client'
  document.getElementById("client-form").reset()
  delete document.getElementById("client-form").dataset.editId
  openModal("client-modal")
}

function editClient(client) {
  document.getElementById("modal-title").innerHTML = '<i class="fas fa-user-edit"></i> Modifier le client'

  // Remplir le formulaire
  document.getElementById("nom").value = client.nom
  document.getElementById("prenom").value = client.prenom || ""
  document.getElementById("email").value = client.email || ""
  document.getElementById("telephone").value = client.telephone || ""
  document.getElementById("adresse").value = client.adresse || ""

  // Stocker l'ID pour la modification
  document.getElementById("client-form").dataset.editId = client.id

  openModal("client-modal")
}

async function deleteClient(client) {
  const clientName = `${client.nom} ${client.prenom || ""}`.trim()
  if (confirm(`Êtes-vous sûr de v\
