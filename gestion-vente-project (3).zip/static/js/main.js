// Fonctions utilitaires globales
class API {
  static async get(url) {
    try {
      const response = await fetch(url)
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      return await response.json()
    } catch (error) {
      console.error("Erreur GET:", error)
      throw error
    }
  }

  static async post(url, data) {
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      return await response.json()
    } catch (error) {
      console.error("Erreur POST:", error)
      throw error
    }
  }

  static async put(url, data) {
    try {
      const response = await fetch(url, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      return await response.json()
    } catch (error) {
      console.error("Erreur PUT:", error)
      throw error
    }
  }

  static async delete(url) {
    try {
      const response = await fetch(url, {
        method: "DELETE",
      })
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      return await response.json()
    } catch (error) {
      console.error("Erreur DELETE:", error)
      throw error
    }
  }
}

// Fonctions utilitaires pour les modales
function openModal(modalId) {
  document.getElementById(modalId).style.display = "block"
  document.body.style.overflow = "hidden"
}

function closeModal() {
  const modals = document.querySelectorAll(".modal")
  modals.forEach((modal) => {
    modal.style.display = "none"
  })
  document.body.style.overflow = "auto"
}

// Fermer la modale en cliquant à l'extérieur
window.onclick = (event) => {
  if (event.target.classList.contains("modal")) {
    closeModal()
  }
}

// Fonctions utilitaires pour les tableaux
function createTableRow(data, columns, actions = []) {
  const row = document.createElement("tr")

  columns.forEach((column) => {
    const cell = document.createElement("td")
    if (typeof column === "function") {
      cell.innerHTML = column(data)
    } else {
      cell.textContent = data[column] || ""
    }
    row.appendChild(cell)
  })

  if (actions.length > 0) {
    const actionsCell = document.createElement("td")
    actionsCell.className = "actions"

    actions.forEach((action, index) => {
      const button = document.createElement("button")
      button.className = `btn btn-sm ${action.class}`
      button.innerHTML = `<i class="${action.icon}"></i> ${action.text}`
      button.onclick = () => action.handler(data)

      if (index > 0) {
        actionsCell.appendChild(document.createTextNode(" "))
      }
      actionsCell.appendChild(button)
    })

    row.appendChild(actionsCell)
  }

  return row
}

// Fonction pour formater les prix
function formatPrice(price) {
  return (
    new Intl.NumberFormat("fr-MA", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price) + " DH"
  )
}

// Fonction pour formater les dates
function formatDate(dateString) {
  if (!dateString) return ""
  const date = new Date(dateString)
  return date.toLocaleDateString("fr-FR")
}

// Fonction pour créer un badge de statut
function createStatusBadge(status) {
  const statusClass = `status-${status.toLowerCase().replace(/[^a-z0-9]/g, "-")}`
  return `<span class="status ${statusClass}">${status}</span>`
}

// Fonction pour créer un badge de stock
function createStockBadge(quantity) {
  let statusClass, statusText

  if (quantity < 10) {
    statusClass = "status-low"
    statusText = "Stock faible"
  } else if (quantity < 50) {
    statusClass = "status-medium"
    statusText = "Stock moyen"
  } else {
    statusClass = "status-high"
    statusText = "Stock élevé"
  }

  return `<span class="status ${statusClass}">${statusText}</span>`
}

// Fonction pour afficher les notifications
function showNotification(message, type = "success") {
  // Supprimer les notifications existantes
  const existingNotifications = document.querySelectorAll(".notification")
  existingNotifications.forEach((notif) => notif.remove())

  const notification = document.createElement("div")
  notification.className = `notification ${type}`

  const icon = type === "success" ? "check-circle" : type === "error" ? "exclamation-circle" : "exclamation-triangle"

  notification.innerHTML = `
    <i class="fas fa-${icon}"></i>
    ${message}
  `

  document.body.appendChild(notification)

  // Supprimer après 5 secondes
  setTimeout(() => {
    notification.remove()
  }, 5000)
}

// Fonction pour filtrer les tableaux
function filterTable(tableId, searchValue, additionalFilters = {}) {
  const table = document.getElementById(tableId)
  const rows = table.querySelectorAll("tbody tr")

  rows.forEach((row) => {
    let showRow = true

    // Filtre de recherche
    if (searchValue) {
      const text = row.textContent.toLowerCase()
      showRow = text.includes(searchValue.toLowerCase())
    }

    // Filtres additionnels
    Object.entries(additionalFilters).forEach(([filterType, filterValue]) => {
      if (showRow && filterValue) {
        // Logique de filtrage spécifique selon le type
        const cells = row.querySelectorAll("td")
        let matchFound = false

        cells.forEach((cell) => {
          if (cell.textContent.toLowerCase().includes(filterValue.toLowerCase())) {
            matchFound = true
          }
        })

        if (!matchFound) {
          showRow = false
        }
      }
    })

    row.style.display = showRow ? "" : "none"
  })
}

// Fonction pour exporter des données
function exportData(type) {
  showNotification(`Export ${type} en cours...`, "warning")

  // Simulation d'export - dans un vrai projet, cela ferait un appel API
  setTimeout(() => {
    showNotification(`Export ${type} terminé avec succès!`, "success")
  }, 2000)
}

// Fonction pour valider les formulaires
function validateForm(formId, rules) {
  const form = document.getElementById(formId)
  const formData = new FormData(form)
  const errors = []

  Object.entries(rules).forEach(([field, rule]) => {
    const value = formData.get(field)

    if (rule.required && (!value || value.trim() === "")) {
      errors.push(`Le champ ${rule.label} est requis`)
    }

    if (rule.type === "email" && value && !isValidEmail(value)) {
      errors.push(`Le champ ${rule.label} doit être un email valide`)
    }

    if (rule.type === "number" && value && isNaN(value)) {
      errors.push(`Le champ ${rule.label} doit être un nombre`)
    }

    if (rule.min && value && Number.parseFloat(value) < rule.min) {
      errors.push(`Le champ ${rule.label} doit être supérieur à ${rule.min}`)
    }
  })

  return errors
}

// Fonction pour valider un email
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

// Fonction pour formater les numéros de téléphone
function formatPhoneNumber(phone) {
  if (!phone) return ""
  // Format marocain: 06XX XX XX XX
  const cleaned = phone.replace(/\D/g, "")
  if (cleaned.length === 10) {
    return cleaned.replace(/(\d{4})(\d{2})(\d{2})(\d{2})/, "$1 $2 $3 $4")
  }
  return phone
}

// Fonction pour débouncer les recherches
function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

// Initialisation globale
document.addEventListener("DOMContentLoaded", () => {
  // Ajouter les événements pour fermer les modales avec Escape
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeModal()
    }
  })

  // Ajouter la classe active au lien de navigation actuel
  const currentPath = window.location.pathname
  const navLinks = document.querySelectorAll(".nav-link")

  navLinks.forEach((link) => {
    if (link.getAttribute("href") === currentPath) {
      link.classList.add("active")
    }
  })

  // Initialiser les tooltips si nécessaire
  initializeTooltips()

  // Ajouter des gestionnaires d'événements globaux
  setupGlobalEventListeners()
})

// Fonction pour initialiser les tooltips
function initializeTooltips() {
  const elementsWithTooltips = document.querySelectorAll("[data-tooltip]")
  elementsWithTooltips.forEach((element) => {
    element.addEventListener("mouseenter", showTooltip)
    element.addEventListener("mouseleave", hideTooltip)
  })
}

// Fonctions pour les tooltips
function showTooltip(event) {
  const tooltip = document.createElement("div")
  tooltip.className = "tooltip"
  tooltip.textContent = event.target.getAttribute("data-tooltip")
  document.body.appendChild(tooltip)

  const rect = event.target.getBoundingClientRect()
  tooltip.style.left = rect.left + rect.width / 2 - tooltip.offsetWidth / 2 + "px"
  tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + "px"
}

function hideTooltip() {
  const tooltip = document.querySelector(".tooltip")
  if (tooltip) {
    tooltip.remove()
  }
}

// Configuration des gestionnaires d'événements globaux
function setupGlobalEventListeners() {
  // Gestionnaire pour les boutons de confirmation
  document.addEventListener("click", (event) => {
    if (event.target.classList.contains("confirm-action")) {
      const message = event.target.getAttribute("data-confirm") || "Êtes-vous sûr ?"
      if (!confirm(message)) {
        event.preventDefault()
        event.stopPropagation()
      }
    }
  })

  // Gestionnaire pour les champs numériques
  document.addEventListener("input", (event) => {
    if (event.target.type === "number") {
      const value = Number.parseFloat(event.target.value)
      const min = Number.parseFloat(event.target.min)
      const max = Number.parseFloat(event.target.max)

      if (min !== undefined && value < min) {
        event.target.setCustomValidity(`La valeur doit être supérieure ou égale à ${min}`)
      } else if (max !== undefined && value > max) {
        event.target.setCustomValidity(`La valeur doit être inférieure ou égale à ${max}`)
      } else {
        event.target.setCustomValidity("")
      }
    }
  })
}

// Fonction utilitaire pour gérer les erreurs
function handleError(error, context = "") {
  console.error(`Erreur ${context}:`, error)

  let message = "Une erreur inattendue s'est produite"

  if (error.message) {
    if (error.message.includes("fetch")) {
      message = "Erreur de connexion au serveur"
    } else if (error.message.includes("JSON")) {
      message = "Erreur de format des données"
    } else {
      message = error.message
    }
  }

  showNotification(message, "error")
}

// Fonction pour recharger les données
function refreshData(callback) {
  if (typeof callback === "function") {
    callback()
  }
}

// Export des fonctions pour utilisation dans d'autres scripts
window.API = API
window.showNotification = showNotification
window.formatPrice = formatPrice
window.formatDate = formatDate
window.createStatusBadge = createStatusBadge
window.createStockBadge = createStockBadge
window.createTableRow = createTableRow
window.openModal = openModal
window.closeModal = closeModal
window.filterTable = filterTable
window.exportData = exportData
window.validateForm = validateForm
window.handleError = handleError
window.debounce = debounce
