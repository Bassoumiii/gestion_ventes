// Gestion des stocks
let produits = []
let API // Declare API variable
let showNotification // Declare showNotification variable
let createTableRow // Declare createTableRow variable
let formatPrice // Declare formatPrice variable
let createStockBadge // Declare createStockBadge variable
let openModal // Declare openModal variable
let closeModal // Declare closeModal variable

document.addEventListener("DOMContentLoaded", () => {
  loadStocks()
  setupEventListeners()
})

function setupEventListeners() {
  // Recherche
  document.getElementById("search-input").addEventListener("input", () => {
    filterStocks()
  })

  // Filtre par niveau de stock
  document.getElementById("stock-filter").addEventListener("change", () => {
    filterStocks()
  })

  // Formulaire de stock
  document.getElementById("stock-form").addEventListener("submit", handleStockSubmit)
}

async function loadStocks() {
  try {
    produits = await API.get("/api/produits")
    displayStocks(produits)
  } catch (error) {
    console.error("Erreur lors du chargement des stocks:", error)
    showNotification("Erreur lors du chargement des stocks", "error")
  }
}

function displayStocks(produitsToShow) {
  const tbody = document.querySelector("#stocks-table tbody")
  tbody.innerHTML = ""

  produitsToShow.forEach((produit) => {
    const row = createTableRow(
      produit,
      [
        "nom",
        "categorie",
        "fournisseur",
        "stock",
        (data) => formatPrice(data.prix),
        (data) => createStockBadge(data.stock),
      ],
      [
        {
          text: "Ajuster",
          icon: "fas fa-edit",
          class: "btn-warning",
          handler: adjustStock,
        },
      ],
    )
    tbody.appendChild(row)
  })
}

function filterStocks() {
  const searchValue = document.getElementById("search-input").value.toLowerCase()
  const stockFilter = document.getElementById("stock-filter").value

  let filteredProduits = produits

  if (searchValue) {
    filteredProduits = filteredProduits.filter(
      (produit) =>
        produit.nom.toLowerCase().includes(searchValue) ||
        (produit.categorie && produit.categorie.toLowerCase().includes(searchValue)) ||
        (produit.fournisseur && produit.fournisseur.toLowerCase().includes(searchValue)),
    )
  }

  if (stockFilter) {
    switch (stockFilter) {
      case "low":
        filteredProduits = filteredProduits.filter((p) => p.stock < 10)
        break
      case "medium":
        filteredProduits = filteredProduits.filter((p) => p.stock >= 10 && p.stock <= 50)
        break
      case "high":
        filteredProduits = filteredProduits.filter((p) => p.stock > 50)
        break
    }
  }

  displayStocks(filteredProduits)
}

function adjustStock(produit) {
  document.getElementById("produit-nom").value = produit.nom
  document.getElementById("stock-actuel").value = produit.stock
  document.getElementById("nouveau-stock").value = produit.stock

  // Stocker l'ID pour la modification
  document.getElementById("stock-form").dataset.produitId = produit.id

  openModal("stock-modal")
}

async function handleStockSubmit(event) {
  event.preventDefault()

  const produitId = event.target.dataset.produitId
  const nouveauStock = document.getElementById("nouveau-stock").value

  try {
    await API.put(`/api/stocks/${produitId}`, { quantite: Number.parseInt(nouveauStock) })
    showNotification("Stock mis à jour avec succès")
    closeModal()
    loadStocks()
  } catch (error) {
    console.error("Erreur lors de la mise à jour du stock:", error)
    showNotification("Erreur lors de la mise à jour du stock", "error")
  }
}
