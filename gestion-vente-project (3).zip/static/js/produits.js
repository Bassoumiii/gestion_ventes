// Gestion des produits
let produits = []
let categories = []
let fournisseurs = []

// Déclaration des variables nécessaires
const API = {
  get: async (url) => {
    const response = await fetch(url)
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return response.json()
  },
  post: async (url, data) => {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return response.json()
  },
  put: async (url, data) => {
    const response = await fetch(url, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return response.json()
  },
  delete: async (url) => {
    const response = await fetch(url, {
      method: "DELETE",
    })
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
  },
}

const debounce = (func, wait) => {
  let timeout
  return function (...args) {
    
    clearTimeout(timeout)
    timeout = setTimeout(() => func.apply(this, args), wait)
  }
}

const handleError = (error, context) => {
  console.error(`Erreur ${context}:`, error)
}

const createTableRow = (produit, columns, actions) => {
  const row = document.createElement("tr")
  columns.forEach((column) => {
    const cell = document.createElement("td")
    if (typeof column === "function") {
      cell.innerHTML = column(produit)
    } else {
      cell.innerHTML = produit[column]
    }
    row.appendChild(cell)
  })

  const actionCell = document.createElement("td")
  actions.forEach((action) => {
    const button = document.createElement("button")
    button.className = `btn ${action.class}`
    button.innerHTML = `<i class="${action.icon}"></i> ${action.text}`
    button.addEventListener("click", () => action.handler(produit))
    actionCell.appendChild(button)
  })

  row.appendChild(actionCell)
  return row
}

const formatPrice = (price) => {
  return price.toFixed(2) + " €"
}

const createStockBadge = (stock) => {
  if (stock > 0) {
    return '<span class="badge bg-success">En stock</span>'
  } else {
    return '<span class="badge bg-danger">Rupture de stock</span>'
  }
}

const openModal = (modalId) => {
  document.getElementById(modalId).style.display = "block"
}

const showNotification = (message, type = "success") => {
  const notification = document.createElement("div")
  notification.className = `notification ${type}`
  notification.innerHTML = message
  document.body.appendChild(notification)
  setTimeout(() => document.body.removeChild(notification), 3000)
}

const validateForm = (formId, rules) => {
  const form = document.getElementById(formId)
  const inputs = form.querySelectorAll("input, select")
  const errors = []

  inputs.forEach((input) => {
    const rule = rules[input.name]
    if (rule.required && !input.value) {
      errors.push(`${rule.label} est requis`)
    }
    if (rule.type === "number" && isNaN(input.value)) {
      errors.push(`${rule.label} doit être un nombre`)
    }
    if (rule.min !== undefined && Number.parseFloat(input.value) < rule.min) {
      errors.push(`${rule.label} doit être au moins ${rule.min}`)
    }
  })

  return errors
}

const closeModal = () => {
  document.getElementById("product-modal").style.display = "none"
}

document.addEventListener("DOMContentLoaded", () => {
  loadProduits()
  loadCategories()
  loadFournisseurs()
  setupEventListeners()
})

function setupEventListeners() {
  // Recherche avec debounce
  const searchInput = document.getElementById("search-input")
  if (searchInput) {
    searchInput.addEventListener(
      "input",
      debounce(() => {
        filterProduits()
      }, 300),
    )
  }

  // Filtres
  const categoryFilter = document.getElementById("category-filter")
  if (categoryFilter) {
    categoryFilter.addEventListener("change", filterProduits)
  }

  const fournisseurFilter = document.getElementById("fournisseur-filter")
  if (fournisseurFilter) {
    fournisseurFilter.addEventListener("change", filterProduits)
  }

  // Formulaire de produit
  const productForm = document.getElementById("product-form")
  if (productForm) {
    productForm.addEventListener("submit", handleProductSubmit)
  }
}

async function loadProduits() {
  try {
    produits = await API.get("/api/produits")
    displayProduits(produits)
  } catch (error) {
    handleError(error, "lors du chargement des produits")
    displayEmptyState("produits-table", "Erreur de chargement des produits")
  }
}

async function loadCategories() {
  try {
    categories = await API.get("/api/categories")

    // Remplir le filtre de catégories
    const categoryFilter = document.getElementById("category-filter")
    if (categoryFilter) {
      categoryFilter.innerHTML = '<option value="">Toutes les catégories</option>'
      categories.forEach((categorie) => {
        const option = new Option(categorie.nom, categorie.nom)
        categoryFilter.appendChild(option)
      })
    }

    // Remplir le select du formulaire
    const categorySelect = document.getElementById("id_categorie")
    if (categorySelect) {
      categorySelect.innerHTML = '<option value="">Sélectionner une catégorie</option>'
      categories.forEach((categorie) => {
        const option = new Option(categorie.nom, categorie.id)
        categorySelect.appendChild(option)
      })
    }
  } catch (error) {
    console.error("Erreur lors du chargement des catégories:", error)
  }
}

async function loadFournisseurs() {
  try {
    fournisseurs = await API.get("/api/fournisseurs")

    // Remplir le filtre de fournisseurs
    const fournisseurFilter = document.getElementById("fournisseur-filter")
    if (fournisseurFilter) {
      fournisseurFilter.innerHTML = '<option value="">Tous les fournisseurs</option>'
      fournisseurs.forEach((fournisseur) => {
        const option = new Option(fournisseur.nom, fournisseur.nom)
        fournisseurFilter.appendChild(option)
      })
    }

    // Remplir le select du formulaire
    const fournisseurSelect = document.getElementById("id_fournisseur")
    if (fournisseurSelect) {
      fournisseurSelect.innerHTML = '<option value="">Sélectionner un fournisseur</option>'
      fournisseurs.forEach((fournisseur) => {
        const option = new Option(fournisseur.nom, fournisseur.id)
        fournisseurSelect.appendChild(option)
      })
    }
  } catch (error) {
    console.error("Erreur lors du chargement des fournisseurs:", error)
  }
}

function displayProduits(produitsToShow) {
  const tbody = document.querySelector("#produits-table tbody")
  if (!tbody) return

  tbody.innerHTML = ""

  if (produitsToShow.length === 0) {
    displayEmptyState("produits-table", "Aucun produit trouvé")
    return
  }

  produitsToShow.forEach((produit) => {
    const row = createTableRow(
      produit,
      [
        "id",
        "nom",
        (data) => data.description || "Aucune description",
        (data) => formatPrice(data.prix),
        "categorie",
        "fournisseur",
        (data) => `${data.stock} ${createStockBadge(data.stock)}`,
      ],
      [
        {
          text: "Modifier",
          icon: "fas fa-edit",
          class: "btn-warning",
          handler: editProduit,
        },
        {
          text: "Supprimer",
          icon: "fas fa-trash",
          class: "btn-danger confirm-action",
          handler: deleteProduit,
        },
      ],
    )
    tbody.appendChild(row)
  })
}

function displayEmptyState(tableId, message) {
  const tbody = document.querySelector(`#${tableId} tbody`)
  if (!tbody) return

  const colCount = document.querySelectorAll(`#${tableId} thead th`).length
  tbody.innerHTML = `
    <tr>
      <td colspan="${colCount}" class="empty-state">
        <i class="fas fa-box-open"></i>
        ${message}
      </td>
    </tr>
  `
}

function filterProduits() {
  const searchValue = document.getElementById("search-input")?.value || ""
  const categoryValue = document.getElementById("category-filter")?.value || ""
  const fournisseurValue = document.getElementById("fournisseur-filter")?.value || ""

  let filteredProduits = produits

  if (searchValue) {
    filteredProduits = filteredProduits.filter(
      (produit) =>
        produit.nom.toLowerCase().includes(searchValue.toLowerCase()) ||
        (produit.description && produit.description.toLowerCase().includes(searchValue.toLowerCase())),
    )
  }

  if (categoryValue) {
    filteredProduits = filteredProduits.filter((produit) => produit.categorie === categoryValue)
  }

  if (fournisseurValue) {
    filteredProduits = filteredProduits.filter((produit) => produit.fournisseur === fournisseurValue)
  }

  displayProduits(filteredProduits)
}

function openAddModal() {
  document.getElementById("modal-title").innerHTML = '<i class="fas fa-plus"></i> Ajouter un produit'
  document.getElementById("product-form").reset()
  delete document.getElementById("product-form").dataset.editId
  openModal("product-modal")
}

function editProduit(produit) {
  document.getElementById("modal-title").innerHTML = '<i class="fas fa-edit"></i> Modifier le produit'

  // Remplir le formulaire
  document.getElementById("nom_produit").value = produit.nom
  document.getElementById("description").value = produit.description || ""
  document.getElementById("prix").value = produit.prix

  // Sélectionner la catégorie
  const categorySelect = document.getElementById("id_categorie")
  const category = categories.find((c) => c.nom === produit.categorie)
  if (category) {
    categorySelect.value = category.id
  }

  // Sélectionner le fournisseur
  const fournisseurSelect = document.getElementById("id_fournisseur")
  const fournisseur = fournisseurs.find((f) => f.nom === produit.fournisseur)
  if (fournisseur) {
    fournisseurSelect.value = fournisseur.id
  }

  // Stocker l'ID pour la modification
  document.getElementById("product-form").dataset.editId = produit.id

  openModal("product-modal")
}

async function deleteProduit(produit) {
  if (confirm(`Êtes-vous sûr de vouloir supprimer le produit "${produit.nom}" ?\n\nCette action est irréversible.`)) {
    try {
      await API.delete(`/api/produits/${produit.id}`)
      showNotification("Produit supprimé avec succès")
      loadProduits()
    } catch (error) {
      handleError(error, "lors de la suppression du produit")
    }
  }
}

async function handleProductSubmit(event) {
  event.preventDefault()

  const formData = new FormData(event.target)
  const data = Object.fromEntries(formData.entries())

  // Validation
  const errors = validateForm("product-form", {
    nom_produit: { required: true, label: "Nom du produit" },
    prix: { required: true, type: "number", min: 0, label: "Prix" },
    id_categorie: { required: true, label: "Catégorie" },
    id_fournisseur: { required: true, label: "Fournisseur" },
  })

  if (errors.length > 0) {
    showNotification(errors.join("\n"), "error")
    return
  }

  try {
    const editId = event.target.dataset.editId

    if (editId) {
      // Modification
      await API.put(`/api/produits/${editId}`, data)
      showNotification("Produit modifié avec succès")
    } else {
      // Ajout
      await API.post("/api/produits", data)
      showNotification("Produit ajouté avec succès")
    }

    closeModal()
    loadProduits()
    event.target.reset()
    delete event.target.dataset.editId
  } catch (error) {
    handleError(error, "lors de la sauvegarde du produit")
  }
}

// Fonction pour exporter les produits
function exportProduits() {
  const csvContent =
    "data:text/csv;charset=utf-8," +
    "ID,Nom,Description,Prix,Catégorie,Fournisseur,Stock\n" +
    produits
      .map(
        (p) => `${p.id},"${p.nom}","${p.description || ""}",${p.prix},"${p.categorie}","${p.fournisseur}",${p.stock}`,
      )
      .join("\n")

  const encodedUri = encodeURI(csvContent)
  const link = document.createElement("a")
  link.setAttribute("href", encodedUri)
  link.setAttribute("download", `produits_${new Date().toISOString().split("T")[0]}.csv`)
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)

  showNotification("Export des produits terminé")
}

// Exposer la fonction d'export globalement
window.exportProduits = exportProduits
