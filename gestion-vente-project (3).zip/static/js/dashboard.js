// Dashboard JavaScript
document.addEventListener("DOMContentLoaded", () => {
  loadDashboardData()

  // Actualiser les données toutes les 5 minutes
  setInterval(loadDashboardData, 300000)
})

async function loadDashboardData() {
  try {
    // Charger les statistiques
    await loadStats()

    // Charger les commandes récentes
    await loadRecentOrders()

    // Charger les produits en stock faible
    await loadLowStockProducts()
  } catch (error) {
    console.error("Erreur lors du chargement du dashboard:", error)
  }
}

async function loadStats() {
  try {
    const stats = await API.get("/api/stats")

    // Mettre à jour les statistiques avec animation
    animateCounter("total-produits", stats.total_produits || 0)
    animateCounter("total-clients", stats.total_clients || 0)
    animateCounter("total-commandes", stats.total_commandes || 0)
    animateCounter("stock-faible", stats.stock_faible || 0)

    // Formater le chiffre d'affaires
    const caElement = document.getElementById("ca-mois")
    if (caElement) {
      caElement.textContent = formatPrice(stats.ca_mois || 0)
    }
  } catch (error) {
    console.error("Erreur lors du chargement des statistiques:", error)
    // Afficher des valeurs par défaut en cas d'erreur
    document.getElementById("total-produits").textContent = "0"
    document.getElementById("total-clients").textContent = "0"
    document.getElementById("total-commandes").textContent = "0"
    document.getElementById("stock-faible").textContent = "0"
    document.getElementById("ca-mois").textContent = "0 DH"
  }
}

async function loadRecentOrders() {
  try {
    const commandes = await API.get("/api/commandes")
    const tbody = document.querySelector("#recent-orders-table tbody")

    if (!tbody) return

    tbody.innerHTML = ""

    // Prendre les 5 dernières commandes
    const recentOrders = commandes.slice(0, 5)

    if (recentOrders.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="5" class="empty-state">
            <i class="fas fa-shopping-cart"></i>
            Aucune commande récente
          </td>
        </tr>
      `
      return
    }

    recentOrders.forEach((commande) => {
      const row = createTableRow(commande, [
        "id",
        (data) => `${data.client_nom} ${data.client_prenom}`,
        (data) => formatDate(data.date),
        (data) => createStatusBadge(data.statut),
        (data) => formatPrice(data.total || 0),
      ])
      tbody.appendChild(row)
    })
  } catch (error) {
    console.error("Erreur lors du chargement des commandes récentes:", error)
    const tbody = document.querySelector("#recent-orders-table tbody")
    if (tbody) {
      tbody.innerHTML = `
        <tr>
          <td colspan="5" class="empty-state">
            <i class="fas fa-exclamation-triangle"></i>
            Erreur de chargement
          </td>
        </tr>
      `
    }
  }
}

async function loadLowStockProducts() {
  try {
    const produits = await API.get("/api/produits")
    const tbody = document.querySelector("#low-stock-table tbody")

    if (!tbody) return

    tbody.innerHTML = ""

    // Filtrer les produits avec stock faible
    const lowStockProducts = produits.filter((p) => p.stock < 10)

    if (lowStockProducts.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="4" class="empty-state">
            <i class="fas fa-check-circle"></i>
            Tous les stocks sont suffisants
          </td>
        </tr>
      `
      return
    }

    lowStockProducts.forEach((produit) => {
      const row = createTableRow(produit, [
        "nom",
        "stock",
        (data) => formatPrice(data.prix),
        (data) => createStockBadge(data.stock),
      ])
      tbody.appendChild(row)
    })
  } catch (error) {
    console.error("Erreur lors du chargement des produits en stock faible:", error)
    const tbody = document.querySelector("#low-stock-table tbody")
    if (tbody) {
      tbody.innerHTML = `
        <tr>
          <td colspan="4" class="empty-state">
            <i class="fas fa-exclamation-triangle"></i>
            Erreur de chargement
          </td>
        </tr>
      `
    }
  }
}

// Fonction pour animer les compteurs
function animateCounter(elementId, targetValue) {
  const element = document.getElementById(elementId)
  if (!element) return

  const startValue = 0
  const duration = 1000 // 1 seconde
  const startTime = performance.now()

  function updateCounter(currentTime) {
    const elapsed = currentTime - startTime
    const progress = Math.min(elapsed / duration, 1)

    // Fonction d'easing pour une animation plus fluide
    const easeOutQuart = 1 - Math.pow(1 - progress, 4)
    const currentValue = Math.floor(startValue + (targetValue - startValue) * easeOutQuart)

    element.textContent = currentValue.toLocaleString()

    if (progress < 1) {
      requestAnimationFrame(updateCounter)
    } else {
      element.textContent = targetValue.toLocaleString()
    }
  }

  requestAnimationFrame(updateCounter)
}

// Fonction pour actualiser le dashboard
function refreshDashboard() {
  // Afficher un indicateur de chargement
  const statsCards = document.querySelectorAll(".stat-content h3")
  statsCards.forEach((card) => {
    card.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'
  })

  // Recharger les données
  loadDashboardData()
}

// Ajouter un bouton de rafraîchissement si nécessaire
document.addEventListener("DOMContentLoaded", () => {
  const dashboardHeader = document.querySelector(".dashboard-header")
  if (dashboardHeader) {
    const refreshButton = document.createElement("button")
    refreshButton.className = "btn btn-secondary btn-sm"
    refreshButton.innerHTML = '<i class="fas fa-sync-alt"></i> Actualiser'
    refreshButton.onclick = refreshDashboard
    refreshButton.style.position = "absolute"
    refreshButton.style.top = "2rem"
    refreshButton.style.right = "2rem"

    dashboardHeader.style.position = "relative"
    dashboardHeader.appendChild(refreshButton)
  }
})

// Déclaration des variables nécessaires
const API = {
  get: async (url) => {
    const response = await fetch(url)
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return response.json()
  },
}

function formatPrice(price) {
  return `${price.toLocaleString()} DH`
}

function formatDate(date) {
  return new Date(date).toLocaleDateString()
}

function createStatusBadge(status) {
  const badge = document.createElement("span")
  badge.className = `badge badge-${status === "completed" ? "success" : "warning"}`
  badge.textContent = status.charAt(0).toUpperCase() + status.slice(1)
  return badge.outerHTML
}

function createStockBadge(stock) {
  const badge = document.createElement("span")
  badge.className = `badge badge-${stock < 5 ? "danger" : "warning"}`
  badge.textContent = stock
  return badge.outerHTML
}

function createTableRow(data, columns) {
  const row = document.createElement("tr")
  columns.forEach((column) => {
    const cell = document.createElement("td")
    if (typeof column === "string") {
      cell.textContent = data[column]
    } else if (typeof column === "function") {
      cell.innerHTML = column(data)
    }
    row.appendChild(cell)
  })
  return row
}
