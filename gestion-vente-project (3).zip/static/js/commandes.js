// Gestion des commandes
let commandes = []
let clients = []
let produits = []
let orderItems = []

// Declare API variable
const API = {
  get: async (url) => {
    const response = await fetch(url)
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return await response.json()
  },
  post: async (url, data) => {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    return await response.json()
  },
  delete: async (url) => {
    const response = await fetch(url, {
      method: "DELETE",
    })
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
  },
}

// Declare showNotification function
function showNotification(message, type = "success") {
  const notification = document.createElement("div")
  notification.className = `notification ${type}`
  notification.textContent = message
  document.body.appendChild(notification)

  setTimeout(() => {
    document.body.removeChild(notification)
  }, 3000)
}

// Declare formatPrice function
function formatPrice(price) {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
  }).format(price)
}

// Declare createTableRow function
function createTableRow(data, columns, actions) {
  const row = document.createElement("tr")
  columns.forEach((column) => {
    const cell = document.createElement("td")
    if (typeof column === "function") {
      cell.textContent = column(data)
    } else {
      cell.textContent = data[column]
    }
    row.appendChild(cell)
  })

  const actionsCell = document.createElement("td")
  actions.forEach((action) => {
    const button = document.createElement("button")
    button.type = "button"
    button.className = `btn btn-sm ${action.class}`
    button.innerHTML = `<i class="${action.icon}"></i> ${action.text}`
    button.addEventListener("click", () => action.handler(data))
    actionsCell.appendChild(button)
  })

  row.appendChild(actionsCell)
  return row
}

// Declare formatDate function
function formatDate(date) {
  return new Date(date).toLocaleDateString("fr-FR", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  })
}

// Declare createStatusBadge function
function createStatusBadge(status) {
  const badge = document.createElement("span")
  badge.className = `badge badge-${status === "En cours" ? "warning" : status === "Terminée" ? "success" : "danger"}`
  badge.textContent = status
  return badge.outerHTML
}

// Declare openModal function
function openModal(modalId) {
  const modal = document.getElementById(modalId)
  modal.style.display = "block"
}

// Declare closeModal function
function closeModal() {
  const modals = document.querySelectorAll(".modal")
  modals.forEach((modal) => {
    modal.style.display = "none"
  })
}

document.addEventListener("DOMContentLoaded", () => {
  loadCommandes()
  loadClients()
  loadProduits()
  setupEventListeners()
})

function setupEventListeners() {
  // Recherche
  document.getElementById("search-input").addEventListener("input", () => {
    filterCommandes()
  })

  // Filtre par statut
  document.getElementById("status-filter").addEventListener("change", () => {
    filterCommandes()
  })

  // Formulaire de commande
  document.getElementById("commande-form").addEventListener("submit", handleCommandeSubmit)
}

async function loadCommandes() {
  try {
    commandes = await API.get("/api/commandes")
    displayCommandes(commandes)
  } catch (error) {
    console.error("Erreur lors du chargement des commandes:", error)
    showNotification("Erreur lors du chargement des commandes", "error")
  }
}

async function loadClients() {
  try {
    clients = await API.get("/api/clients")

    const clientSelect = document.getElementById("id_client")
    clientSelect.innerHTML = '<option value="">Sélectionner un client</option>'

    clients.forEach((client) => {
      const option = new Option(`${client.nom} ${client.prenom}`, client.id)
      clientSelect.appendChild(option)
    })
  } catch (error) {
    console.error("Erreur lors du chargement des clients:", error)
  }
}

async function loadProduits() {
  try {
    produits = await API.get("/api/produits")

    const produitSelect = document.getElementById("produit-select")
    produitSelect.innerHTML = '<option value="">Sélectionner un produit</option>'

    produits.forEach((produit) => {
      const option = new Option(`${produit.nom} (${formatPrice(produit.prix)})`, produit.id)
      produitSelect.appendChild(option)
    })
  } catch (error) {
    console.error("Erreur lors du chargement des produits:", error)
  }
}

function displayCommandes(commandesToShow) {
  const tbody = document.querySelector("#commandes-table tbody")
  tbody.innerHTML = ""

  commandesToShow.forEach((commande) => {
    const row = createTableRow(
      commande,
      [
        "id",
        (data) => `${data.client_nom} ${data.client_prenom}`,
        (data) => formatDate(data.date),
        (data) => createStatusBadge(data.statut),
        (data) => formatPrice(data.total),
      ],
      [
        {
          text: "Supprimer",
          icon: "fas fa-trash",
          class: "btn-danger",
          handler: deleteCommande,
        },
      ],
    )
    tbody.appendChild(row)
  })
}

function filterCommandes() {
  const searchValue = document.getElementById("search-input").value.toLowerCase()
  const statusValue = document.getElementById("status-filter").value

  let filteredCommandes = commandes

  if (searchValue) {
    filteredCommandes = filteredCommandes.filter(
      (commande) =>
        commande.client_nom.toLowerCase().includes(searchValue) ||
        (commande.client_prenom && commande.client_prenom.toLowerCase().includes(searchValue)) ||
        commande.id.toString().includes(searchValue),
    )
  }

  if (statusValue) {
    filteredCommandes = filteredCommandes.filter((commande) => commande.statut === statusValue)
  }

  displayCommandes(filteredCommandes)
}

function openAddModal() {
  document.getElementById("commande-form").reset()
  orderItems = []
  updateItemsTable()
  updateOrderTotal()
  openModal("commande-modal")
}

function addItem() {
  const produitSelect = document.getElementById("produit-select")
  const quantiteInput = document.getElementById("quantite-input")

  const produitId = produitSelect.value
  const quantite = Number.parseInt(quantiteInput.value)

  if (!produitId || !quantite || quantite <= 0) {
    showNotification("Veuillez sélectionner un produit et une quantité valide", "error")
    return
  }

  const produit = produits.find((p) => p.id == produitId)
  if (!produit) {
    showNotification("Produit non trouvé", "error")
    return
  }

  if (quantite > produit.stock) {
    showNotification("Quantité demandée supérieure au stock disponible", "error")
    return
  }

  // Vérifier si le produit est déjà dans la commande
  const existingItem = orderItems.find((item) => item.id_produit == produitId)
  if (existingItem) {
    existingItem.quantite += quantite
  } else {
    orderItems.push({
      id_produit: produitId,
      nom_produit: produit.nom,
      prix_unitaire: produit.prix,
      quantite: quantite,
    })
  }

  updateItemsTable()
  updateOrderTotal()

  // Reset les champs
  produitSelect.value = ""
  quantiteInput.value = ""
}

function updateItemsTable() {
  const tbody = document.querySelector("#items-table tbody")
  tbody.innerHTML = ""

  orderItems.forEach((item, index) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td>${item.nom_produit}</td>
            <td>${formatPrice(item.prix_unitaire)}</td>
            <td>${item.quantite}</td>
            <td>${formatPrice(item.prix_unitaire * item.quantite)}</td>
            <td>
                <button type="button" class="btn btn-sm btn-danger" onclick="removeItem(${index})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `
    tbody.appendChild(row)
  })
}

function removeItem(index) {
  orderItems.splice(index, 1)
  updateItemsTable()
  updateOrderTotal()
}

function updateOrderTotal() {
  const total = orderItems.reduce((sum, item) => sum + item.prix_unitaire * item.quantite, 0)
  document.getElementById("order-total").textContent = formatPrice(total)
}

async function handleCommandeSubmit(event) {
  event.preventDefault()

  const formData = new FormData(event.target)
  const data = Object.fromEntries(formData.entries())

  if (orderItems.length === 0) {
    showNotification("Veuillez ajouter au moins un article à la commande", "error")
    return
  }

  data.items = orderItems

  try {
    await API.post("/api/commandes", data)
    showNotification("Commande créée avec succès")
    closeModal()
    loadCommandes()
    loadProduits() // Recharger pour mettre à jour les stocks
  } catch (error) {
    console.error("Erreur lors de la création de la commande:", error)
    showNotification("Erreur lors de la création de la commande", "error")
  }
}

async function deleteCommande(commande) {
  if (confirm(`Êtes-vous sûr de vouloir supprimer la commande ${commande.id} ?`)) {
    try {
      await API.delete(`/api/commandes/${commande.id}`)
      showNotification("Commande supprimée avec succès")
      loadCommandes()
    } catch (error) {
      console.error("Erreur lors de la suppression:", error)
      showNotification("Erreur lors de la suppression de la commande", "error")
    }
  }
}
