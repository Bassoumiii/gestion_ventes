from flask import Flask, render_template, request, jsonify, redirect, url_for, session
from flask_cors import CORS
import sqlite3
from datetime import datetime
import os
from functools import wraps

app = Flask(__name__)
app.secret_key = 'gestion-vente-secret-key-2024'
CORS(app)

# Configuration de la base de données SQLite
DATABASE = 'gestion_vente.db'

def get_db_connection():
    """Établit une connexion à la base de données SQLite"""
    try:
        conn = sqlite3.connect(DATABASE)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        print(f"Erreur de connexion à la base de données: {e}")
        return None

def init_database():
    """Initialise la base de données avec les tables nécessaires"""
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        
        # Créer les tables
        cursor.executescript('''
            -- Table des catégories
            CREATE TABLE IF NOT EXISTS Categories (
                id_categorie INTEGER PRIMARY KEY AUTOINCREMENT,
                nom_categorie TEXT NOT NULL UNIQUE
            );

            -- Table des utilisateurs
            CREATE TABLE IF NOT EXISTS Utilisateurs (
                id_utilisateur INTEGER PRIMARY KEY AUTOINCREMENT,
                nom TEXT NOT NULL,
                prenom TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                mot_de_passe TEXT NOT NULL,
                role TEXT DEFAULT 'employe',
                date_creation DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            -- Table des clients
            CREATE TABLE IF NOT EXISTS Clients (
                id_client INTEGER PRIMARY KEY AUTOINCREMENT,
                nom TEXT NOT NULL,
                prenom TEXT,
                email TEXT,
                telephone TEXT,
                adresse TEXT
            );

            -- Table des fournisseurs
            CREATE TABLE IF NOT EXISTS Fournisseurs (
                id_fournisseur INTEGER PRIMARY KEY AUTOINCREMENT,
                nom_fournisseur TEXT NOT NULL,
                contact TEXT,
                telephone TEXT,
                email TEXT
            );

            -- Table des produits
            CREATE TABLE IF NOT EXISTS Produits (
                id_produit INTEGER PRIMARY KEY AUTOINCREMENT,
                nom_produit TEXT NOT NULL,
                description TEXT,
                prix REAL CHECK (prix > 0),
                id_categorie INTEGER,
                id_fournisseur INTEGER,
                FOREIGN KEY (id_categorie) REFERENCES Categories(id_categorie),
                FOREIGN KEY (id_fournisseur) REFERENCES Fournisseurs(id_fournisseur)
            );

            -- Table des stocks
            CREATE TABLE IF NOT EXISTS Stocks (
                id_stock INTEGER PRIMARY KEY AUTOINCREMENT,
                id_produit INTEGER UNIQUE,
                quantite INTEGER CHECK (quantite >= 0),
                FOREIGN KEY (id_produit) REFERENCES Produits(id_produit)
            );

            -- Table des commandes
            CREATE TABLE IF NOT EXISTS Commandes (
                id_commande INTEGER PRIMARY KEY AUTOINCREMENT,
                id_client INTEGER,
                date_commande DATE DEFAULT CURRENT_DATE,
                statut TEXT DEFAULT 'en attente',
                FOREIGN KEY (id_client) REFERENCES Clients(id_client)
            );

            -- Table des lignes de commandes
            CREATE TABLE IF NOT EXISTS Lignes_Commandes (
                id_ligne INTEGER PRIMARY KEY AUTOINCREMENT,
                id_commande INTEGER,
                id_produit INTEGER,
                quantite INTEGER CHECK (quantite > 0),
                prix_unitaire REAL,
                FOREIGN KEY (id_commande) REFERENCES Commandes(id_commande),
                FOREIGN KEY (id_produit) REFERENCES Produits(id_produit)
            );

            -- Table des paiements
            CREATE TABLE IF NOT EXISTS Paiements (
                id_paiement INTEGER PRIMARY KEY AUTOINCREMENT,
                id_commande INTEGER,
                montant REAL,
                date_paiement DATE,
                mode_paiement TEXT,
                FOREIGN KEY (id_commande) REFERENCES Commandes(id_commande)
            );
        ''')
        
        # Insérer des données de test si les tables sont vides
        cursor.execute("SELECT COUNT(*) FROM Utilisateurs")
        if cursor.fetchone()[0] == 0:
            cursor.executescript('''
                -- Utilisateurs de test
                INSERT INTO Utilisateurs (nom, prenom, email, mot_de_passe, role) VALUES
                ('Admin', 'Principal', 'admin@gmail.com', 'admin123', 'admin'),
                ('Fatima', 'Zahra', 'fatima.zh@gmail.com', 'abc123', 'admin'),
                ('Said', 'Ali', 'said.ali@gmail.com', '123456', 'employe');

                -- Catégories
                INSERT INTO Categories (nom_categorie) VALUES
                ('Électronique'),
                ('Alimentation'),
                ('Vêtements'),
                ('Papeterie'),
                ('Sport'),
                ('Jardinage');

                -- Fournisseurs
                INSERT INTO Fournisseurs (nom_fournisseur, contact, telephone, email) VALUES
                ('TechWorld', 'Alice Dubois', '063162233', 'alice@techworld.com'),
                ('SuperFourn', 'Mohamed Karim', '0652233445', 'karim@superfourn.com'),
                ('GlobalPro', 'Hanae Badr', '0693344556', 'hanae@globalpro.com'),
                ('ElectroShop', 'Nizar Said', '0644455667', 'nizar@electroshop.com');

                -- Clients
                INSERT INTO Clients (nom, prenom, email, telephone, adresse) VALUES
                ('El Amrani', 'Sara', 'sara.elamrani@gmail.com', '0641902811', 'Casablanca'),
                ('Benali', 'Ahmed', 'ahmed.benali@gmail.com', '0692803302', 'Rabat'),
                ('Zahraoui', 'Nour', 'nour.zahraoui@gmail.com', '0693194003', 'Fès'),
                ('Tazi', 'Youssef', 'youssef.tazi@gmail.com', '0674995144', 'Agadir');

                -- Produits
                INSERT INTO Produits (nom_produit, description, prix, id_categorie, id_fournisseur) VALUES
                ('Smartphone A1', 'Téléphone Android', 199.99, 1, 1),
                ('Laptop X2', 'Ordinateur portable', 899.00, 1, 1),
                ('Stylo BIC', 'Stylo bleu classique', 2.50, 4, 2),
                ('Vélo Pro', 'Vélo de route', 1500.00, 5, 3),
                ('T-shirt Cool', 'T-shirt coton homme', 80.00, 3, 2),
                ('Tomates Bio', 'Kg de tomates fraîches', 15.00, 2, 4);

                -- Stocks
                INSERT INTO Stocks (id_produit, quantite) VALUES
                (1, 30),
                (2, 15),
                (3, 100),
                (4, 5),
                (5, 60),
                (6, 200);

                -- Commandes
                INSERT INTO Commandes (id_client, date_commande, statut) VALUES
                (1, '2023-04-06', 'payée'),
                (2, '2023-04-09', 'en attente'),
                (3, '2023-05-12', 'payée'),
                (4, '2023-05-14', 'en attente');

                -- Lignes de commandes
                INSERT INTO Lignes_Commandes (id_commande, id_produit, quantite, prix_unitaire) VALUES
                (1, 1, 2, 199.99),
                (2, 3, 5, 2.50),
                (3, 2, 1, 899.00),
                (4, 6, 10, 15.00);

                -- Paiements
                INSERT INTO Paiements (id_commande, montant, date_paiement, mode_paiement) VALUES
                (1, 399.98, '2023-04-06', 'Carte'),
                (3, 899.00, '2023-05-12', 'Virement');
            ''')
        
        conn.commit()
        conn.close()
        print("Base de données initialisée avec succès")

def login_required(f):
    """Décorateur pour vérifier l'authentification"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Routes principales
@app.route('/')
def index():
    if 'user_id' in session:
        return render_template('dashboard.html')
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        conn = get_db_connection()
        if conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id_utilisateur, nom, prenom, role FROM Utilisateurs WHERE email = ? AND mot_de_passe = ?", 
                         (email, password))
            user = cursor.fetchone()
            conn.close()
            
            if user:
                session['user_id'] = user['id_utilisateur']
                session['user_name'] = f"{user['nom']} {user['prenom']}"
                session['user_role'] = user['role']
                return redirect(url_for('index'))
            else:
                return render_template('login.html', error='Email ou mot de passe incorrect')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# API Routes pour les produits
@app.route('/api/produits')
@login_required
def get_produits():
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT p.id_produit, p.nom_produit, p.description, p.prix, 
                   c.nom_categorie, f.nom_fournisseur, COALESCE(s.quantite, 0) as stock
            FROM Produits p
            LEFT JOIN Categories c ON p.id_categorie = c.id_categorie
            LEFT JOIN Fournisseurs f ON p.id_fournisseur = f.id_fournisseur
            LEFT JOIN Stocks s ON p.id_produit = s.id_produit
        """)
        produits = []
        for row in cursor.fetchall():
            produits.append({
                'id': row['id_produit'],
                'nom': row['nom_produit'],
                'description': row['description'] or '',
                'prix': float(row['prix']),
                'categorie': row['nom_categorie'] or '',
                'fournisseur': row['nom_fournisseur'] or '',
                'stock': row['stock']
            })
        conn.close()
        return jsonify(produits)
    return jsonify([])

@app.route('/api/produits', methods=['POST'])
@login_required
def create_produit():
    data = request.json
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO Produits (nom_produit, description, prix, id_categorie, id_fournisseur)
                VALUES (?, ?, ?, ?, ?)
            """, (data['nom_produit'], data.get('description', ''), data['prix'], 
                  data['id_categorie'], data['id_fournisseur']))
            
            produit_id = cursor.lastrowid
            
            # Créer l'entrée stock
            cursor.execute("INSERT INTO Stocks (id_produit, quantite) VALUES (?, 0)", (produit_id,))
            
            conn.commit()
            conn.close()
            return jsonify({'success': True, 'id': produit_id})
        except Exception as e:
            conn.rollback()
            conn.close()
            return jsonify({'success': False, 'error': str(e)})
    return jsonify({'success': False, 'error': 'Erreur de connexion'})

@app.route('/api/produits/<int:produit_id>', methods=['PUT'])
@login_required
def update_produit(produit_id):
    data = request.json
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE Produits 
                SET nom_produit = ?, description = ?, prix = ?, id_categorie = ?, id_fournisseur = ?
                WHERE id_produit = ?
            """, (data['nom_produit'], data.get('description', ''), data['prix'], 
                  data['id_categorie'], data['id_fournisseur'], produit_id))
            conn.commit()
            conn.close()
            return jsonify({'success': True})
        except Exception as e:
            conn.rollback()
            conn.close()
            return jsonify({'success': False, 'error': str(e)})
    return jsonify({'success': False, 'error': 'Erreur de connexion'})

@app.route('/api/produits/<int:produit_id>', methods=['DELETE'])
@login_required
def delete_produit(produit_id):
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM Stocks WHERE id_produit = ?", (produit_id,))
            cursor.execute("DELETE FROM Produits WHERE id_produit = ?", (produit_id,))
            conn.commit()
            conn.close()
            return jsonify({'success': True})
        except Exception as e:
            conn.rollback()
            conn.close()
            return jsonify({'success': False, 'error': str(e)})
    return jsonify({'success': False, 'error': 'Erreur de connexion'})

# API Routes pour les clients
@app.route('/api/clients')
@login_required
def get_clients():
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id_client, nom, prenom, email, telephone, adresse FROM Clients")
        clients = []
        for row in cursor.fetchall():
            clients.append({
                'id': row['id_client'],
                'nom': row['nom'],
                'prenom': row['prenom'] or '',
                'email': row['email'] or '',
                'telephone': row['telephone'] or '',
                'adresse': row['adresse'] or ''
            })
        conn.close()
        return jsonify(clients)
    return jsonify([])

@app.route('/api/clients', methods=['POST'])
@login_required
def create_client():
    data = request.json
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO Clients (nom, prenom, email, telephone, adresse)
                VALUES (?, ?, ?, ?, ?)
            """, (data['nom'], data.get('prenom', ''), data.get('email', ''), 
                  data.get('telephone', ''), data.get('adresse', '')))
            
            client_id = cursor.lastrowid
            
            conn.commit()
            conn.close()
            return jsonify({'success': True, 'id': client_id})
        except Exception as e:
            conn.rollback()
            conn.close()
            return jsonify({'success': False, 'error': str(e)})
    return jsonify({'success': False, 'error': 'Erreur de connexion'})

@app.route('/api/clients/<int:client_id>', methods=['PUT'])
@login_required
def update_client(client_id):
    data = request.json
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE Clients 
                SET nom = ?, prenom = ?, email = ?, telephone = ?, adresse = ?
                WHERE id_client = ?
            """, (data['nom'], data.get('prenom', ''), data.get('email', ''), 
                  data.get('telephone', ''), data.get('adresse', ''), client_id))
            conn.commit()
            conn.close()
            return jsonify({'success': True})
        except Exception as e:
            conn.rollback()
            conn.close()
            return jsonify({'success': False, 'error': str(e)})
    return jsonify({'success': False, 'error': 'Erreur de connexion'})

@app.route('/api/clients/<int:client_id>', methods=['DELETE'])
@login_required
def delete_client(client_id):
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM Clients WHERE id_client = ?", (client_id,))
            conn.commit()
            conn.close()
            return jsonify({'success': True})
        except Exception as e:
            conn.rollback()
            conn.close()
            return jsonify({'success': False, 'error': str(e)})
    return jsonify({'success': False, 'error': 'Erreur de connexion'})

# API Routes pour les commandes
@app.route('/api/commandes')
@login_required
def get_commandes():
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT c.id_commande, cl.nom, cl.prenom, c.date_commande, c.statut,
                   COALESCE(SUM(lc.quantite * lc.prix_unitaire), 0) as total
            FROM Commandes c
            JOIN Clients cl ON c.id_client = cl.id_client
            LEFT JOIN Lignes_Commandes lc ON c.id_commande = lc.id_commande
            GROUP BY c.id_commande, cl.nom, cl.prenom, c.date_commande, c.statut
            ORDER BY c.date_commande DESC
        """)
        commandes = []
        for row in cursor.fetchall():
            commandes.append({
                'id': row['id_commande'],
                'client_nom': row['nom'],
                'client_prenom': row['prenom'] or '',
                'date': row['date_commande'],
                'statut': row['statut'],
                'total': float(row['total']) if row['total'] else 0
            })
        conn.close()
        return jsonify(commandes)
    return jsonify([])

@app.route('/api/commandes', methods=['POST'])
@login_required
def create_commande():
    data = request.json
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            
            # Créer la commande
            cursor.execute("""
                INSERT INTO Commandes (id_client, date_commande, statut)
                VALUES (?, ?, ?)
            """, (data['id_client'], datetime.now().strftime('%Y-%m-%d'), 'en attente'))
            
            commande_id = cursor.lastrowid
            
            # Ajouter les lignes de commande
            for item in data['items']:
                cursor.execute("""
                    INSERT INTO Lignes_Commandes (id_commande, id_produit, quantite, prix_unitaire)
                    VALUES (?, ?, ?, ?)
                """, (commande_id, item['id_produit'], item['quantite'], item['prix_unitaire']))
                
                # Mettre à jour le stock
                cursor.execute("""
                    UPDATE Stocks SET quantite = quantite - ?
                    WHERE id_produit = ?
                """, (item['quantite'], item['id_produit']))
            
            conn.commit()
            conn.close()
            return jsonify({'success': True, 'commande_id': commande_id})
        except Exception as e:
            conn.rollback()
            conn.close()
            return jsonify({'success': False, 'error': str(e)})
    return jsonify({'success': False, 'error': 'Erreur de connexion'})

@app.route('/api/commandes/<int:commande_id>', methods=['DELETE'])
@login_required
def delete_commande(commande_id):
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM Lignes_Commandes WHERE id_commande = ?", (commande_id,))
            cursor.execute("DELETE FROM Commandes WHERE id_commande = ?", (commande_id,))
            conn.commit()
            conn.close()
            return jsonify({'success': True})
        except Exception as e:
            conn.rollback()
            conn.close()
            return jsonify({'success': False, 'error': str(e)})
    return jsonify({'success': False, 'error': 'Erreur de connexion'})

# API Routes pour les paiements
@app.route('/api/paiements')
@login_required
def get_paiements():
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT p.id_paiement, p.id_commande, p.montant, p.date_paiement, p.mode_paiement,
                   cl.nom || ' ' || COALESCE(cl.prenom, '') as client
            FROM Paiements p
            JOIN Commandes c ON p.id_commande = c.id_commande
            JOIN Clients cl ON c.id_client = cl.id_client
            ORDER BY p.date_paiement DESC
        """)
        paiements = []
        for row in cursor.fetchall():
            paiements.append({
                'id': row['id_paiement'],
                'id_commande': row['id_commande'],
                'montant': float(row['montant']),
                'date': row['date_paiement'],
                'mode': row['mode_paiement'],
                'client': row['client']
            })
        conn.close()
        return jsonify(paiements)
    return jsonify([])

@app.route('/api/paiements', methods=['POST'])
@login_required
def create_paiement():
    data = request.json
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO Paiements (id_commande, montant, date_paiement, mode_paiement)
                VALUES (?, ?, ?, ?)
            """, (data['id_commande'], data['montant'], data['date_paiement'], data['mode_paiement']))
            
            # Mettre à jour le statut de la commande si entièrement payée
            cursor.execute("""
                SELECT SUM(quantite * prix_unitaire) as total_commande
                FROM Lignes_Commandes 
                WHERE id_commande = ?
            """, (data['id_commande'],))
            total_commande = cursor.fetchone()['total_commande'] or 0
            
            cursor.execute("""
                SELECT SUM(montant) as total_paye
                FROM Paiements 
                WHERE id_commande = ?
            """, (data['id_commande'],))
            total_paye = cursor.fetchone()['total_paye'] or 0
            
            if total_paye >= total_commande:
                cursor.execute("""
                    UPDATE Commandes SET statut = 'payée' WHERE id_commande = ?
                """, (data['id_commande'],))
            
            conn.commit()
            conn.close()
            return jsonify({'success': True})
        except Exception as e:
            conn.rollback()
            conn.close()
            return jsonify({'success': False, 'error': str(e)})
    return jsonify({'success': False, 'error': 'Erreur de connexion'})

# API Routes pour les catégories et fournisseurs
@app.route('/api/categories')
@login_required
def get_categories():
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id_categorie, nom_categorie FROM Categories")
        categories = []
        for row in cursor.fetchall():
            categories.append({
                'id': row['id_categorie'],
                'nom': row['nom_categorie']
            })
        conn.close()
        return jsonify(categories)
    return jsonify([])

@app.route('/api/fournisseurs')
@login_required
def get_fournisseurs():
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id_fournisseur, nom_fournisseur, contact, telephone, email FROM Fournisseurs")
        fournisseurs = []
        for row in cursor.fetchall():
            fournisseurs.append({
                'id': row['id_fournisseur'],
                'nom': row['nom_fournisseur'],
                'contact': row['contact'] or '',
                'telephone': row['telephone'] or '',
                'email': row['email'] or ''
            })
        conn.close()
        return jsonify(fournisseurs)
    return jsonify([])

# API Routes pour les stocks
@app.route('/api/stocks/<int:produit_id>', methods=['PUT'])
@login_required
def update_stock(produit_id):
    data = request.json
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE Stocks 
                SET quantite = ?
                WHERE id_produit = ?
            """, (data['quantite'], produit_id))
            conn.commit()
            conn.close()
            return jsonify({'success': True})
        except Exception as e:
            conn.rollback()
            conn.close()
            return jsonify({'success': False, 'error': str(e)})
    return jsonify({'success': False, 'error': 'Erreur de connexion'})

# API pour les statistiques du dashboard
@app.route('/api/stats')
@login_required
def get_stats():
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        
        # Statistiques générales
        cursor.execute("SELECT COUNT(*) FROM Produits")
        total_produits = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM Clients")
        total_clients = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM Commandes")
        total_commandes = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM Stocks WHERE quantite < 10")
        stock_faible = cursor.fetchone()[0]
        
        # Chiffre d'affaires du mois
        current_month = datetime.now().strftime('%Y-%m')
        cursor.execute("""
            SELECT COALESCE(SUM(p.montant), 0)
            FROM Paiements p
            WHERE strftime('%Y-%m', p.date_paiement) = ?
        """, (current_month,))
        ca_mois = cursor.fetchone()[0]
        
        conn.close()
        return jsonify({
            'total_produits': total_produits,
            'total_clients': total_clients,
            'total_commandes': total_commandes,
            'stock_faible': stock_faible,
            'ca_mois': float(ca_mois) if ca_mois else 0
        })
    return jsonify({})

# Routes pour les pages
@app.route('/produits')
@login_required
def produits():
    return render_template('produits.html')

@app.route('/clients')
@login_required
def clients():
    return render_template('clients.html')

@app.route('/commandes')
@login_required
def commandes():
    return render_template('commandes.html')

@app.route('/stocks')
@login_required
def stocks():
    return render_template('stocks.html')

@app.route('/paiements')
@login_required
def paiements():
    return render_template('paiements.html')

@app.route('/rapports')
@login_required
def rapports():
    return render_template('rapports.html')

if __name__ == '__main__':
    # Vérifier si la base de données existe, sinon l'initialiser
    if not os.path.exists(DATABASE):
        init_database()
    app.run(debug=True, host='0.0.0.0', port=5000)
