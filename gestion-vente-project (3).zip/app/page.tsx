"use client"

import  from "../static/js/clients"

export default function SyntheticV0PageForDeployment() {
  return < />
}