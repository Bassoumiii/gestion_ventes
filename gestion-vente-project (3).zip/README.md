# Système de Gestion de Vente

Un système complet de gestion de vente développé avec **Python Flask** (backend) et **HTML/CSS/JavaScript** (frontend), utilisant **SQLite** comme base de données.

## 🚀 Fonctionnalités

- **Authentification** : Connexion sécurisée avec différents rôles d'utilisateur
- **Dashboard** : Vue d'ensemble avec statistiques et données importantes
- **Gestion des produits** : CRUD complet pour les produits
- **Gestion des clients** : CRUD complet pour les clients
- **Gestion des commandes** : Création et suivi des commandes avec gestion automatique des stocks
- **Gestion des stocks** : Suivi et ajustement des stocks en temps réel
- **Gestion des paiements** : Enregistrement et suivi des paiements
- **Rapports** : Visualisation des données et statistiques

## 📁 Structure du projet

\`\`\`
gestion-vente/
├── app.py                    # Application Flask principale
├── gestion_vente.db          # Base de données SQLite (créée automatiquement)
├── templates/                # Templates HTML
│   ├── base.html
│   ├── login.html
│   ├── dashboard.html
│   ├── produits.html
│   ├── clients.html
│   ├── commandes.html
│   ├── stocks.html
│   ├── paiements.html
│   └── rapports.html
├── static/                   # Fichiers statiques
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── main.js
│       ├── dashboard.js
│       ├── produits.js
│       ├── clients.js
│       ├── commandes.js
│       ├── stocks.js
│       ├── paiements.js
│       └── rapports.js
├── requirements.txt          # Dépendances Python
└── README.md
\`\`\`

## 🛠️ Installation

### Prérequis

- Python 3.8+ (aucune dépendance C++ requise)
- pip (gestionnaire de paquets Python)

### Étapes d'installation

1. **Télécharger le projet**
   - Cliquer sur "Download Code" en haut à droite
   - Extraire le dossier ZIP

2. **Ouvrir dans VS Code**
   \`\`\`bash
   cd gestion-vente
   code .
   \`\`\`

3. **Créer un environnement virtuel** (recommandé)
   \`\`\`bash
   python -m venv venv
   
   # Activer l'environnement virtuel
   # Sur Windows:
   venv\Scripts\activate
   
   # Sur macOS/Linux:
   source venv/bin/activate
   \`\`\`

4. **Installer les dépendances**
   \`\`\`bash
   pip install -r requirements.txt
   \`\`\`

5. **Lancer l'application**
   \`\`\`bash
   python app.py
   \`\`\`

6. **Accéder à l'application**
   Ouvrir http://localhost:5000 dans votre navigateur

## 👤 Comptes de test

- **Admin** : admin@gmail.com / admin123
- **Admin** : fatima.zh@gmail.com / abc123
- **Employé** : said.ali@gmail.com / 123456

## 🔧 Technologies utilisées

### Backend
- **Flask** : Framework web Python léger et flexible
- **SQLite** : Base de données relationnelle intégrée
- **Flask-CORS** : Gestion des CORS pour les requêtes AJAX

### Frontend
- **HTML5** : Structure des pages
- **CSS3** : Styles modernes et responsive design
- **JavaScript ES6+** : Logique côté client et appels API
- **Font Awesome** : Icônes vectorielles

### Base de données
- **SQLite** : Base de données locale, aucune configuration requise
- **Initialisation automatique** : Tables et données de test créées au premier lancement
- **Gestion des relations** : Clés étrangères et contraintes d'intégrité

## 📊 API Endpoints

### Authentification
- `POST /login` - Connexion utilisateur
- `GET /logout` - Déconnexion

### Produits
- `GET /api/produits` - Liste des produits
- `POST /api/produits` - Créer un produit
- `PUT /api/produits/{id}` - Modifier un produit
- `DELETE /api/produits/{id}` - Supprimer un produit

### Clients
- `GET /api/clients` - Liste des clients
- `POST /api/clients` - Créer un client
- `PUT /api/clients/{id}` - Modifier un client
- `DELETE /api/clients/{id}` - Supprimer un client

### Commandes
- `GET /api/commandes` - Liste des commandes
- `POST /api/commandes` - Créer une commande
- `DELETE /api/commandes/{id}` - Supprimer une commande

### Paiements
- `GET /api/paiements` - Liste des paiements
- `POST /api/paiements` - Créer un paiement

### Autres
- `GET /api/categories` - Liste des catégories
- `GET /api/fournisseurs` - Liste des fournisseurs
- `PUT /api/stocks/{id}` - Mettre à jour le stock
- `GET /api/stats` - Statistiques pour le dashboard

## ✨ Fonctionnalités avancées

- **Gestion automatique des stocks** : Déduction automatique lors des commandes
- **Interface responsive** : Adaptée aux mobiles et tablettes
- **Filtrage en temps réel** : Recherche et filtres dynamiques
- **Notifications utilisateur** : Feedback visuel pour toutes les actions
- **Validation des données** : Côté client et serveur
- **Base de données auto-initialisée** : Aucune configuration manuelle requise

## 🎯 Avantages de cette version

- **Simplicité** : Aucune configuration de base de données externe
- **Portabilité** : Fonctionne sur Windows, macOS et Linux
- **Développement rapide** : Prêt à l'emploi en quelques minutes
- **Code Python pur** : Aucune dépendance C++ ou compilation requise
- **Facilité de déploiement** : Un seul fichier de base de données

## 🚀 Démarrage rapide

\`\`\`bash
# Cloner et naviguer
cd gestion-vente

# Installer les dépendances
pip install flask flask-cors

# Lancer l'application
python app.py

# Ouvrir http://localhost:5000
\`\`\`

## 📝 Notes importantes

- La base de données SQLite est créée automatiquement au premier lancement
- Les données de test sont insérées automatiquement
- Le fichier `gestion_vente.db` contient toutes les données
- Aucune configuration de serveur de base de données requise
- Aucune dépendance C++ n'est nécessaire pour ce projet

## 🤝 Support

Pour toute question ou problème :
1. Vérifier que Python 3.8+ est installé
2. S'assurer que les dépendances sont installées
3. Vérifier que le port 5000 est disponible
4. Consulter les logs dans le terminal pour les erreurs

Bon développement ! 🎉
